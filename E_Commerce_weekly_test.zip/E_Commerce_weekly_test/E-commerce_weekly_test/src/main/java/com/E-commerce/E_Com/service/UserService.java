package com.university.eventmanagement.service;

import org.springframework.stereotype.Service;

// EventService.java
@Service
public class EventService {
    // Implement service methods for CRUD operations
}
