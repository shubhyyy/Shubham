package com.university.eventmanagement.model;

public @interface FutureOrPresent {
}
