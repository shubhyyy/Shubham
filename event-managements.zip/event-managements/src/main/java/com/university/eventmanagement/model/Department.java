package com.university.eventmanagement.model;

public enum Department {
}
