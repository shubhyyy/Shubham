package com.example.usermanagement.controller;

public class User {
}
