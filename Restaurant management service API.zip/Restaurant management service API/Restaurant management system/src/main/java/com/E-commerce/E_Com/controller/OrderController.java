package com.university.eventmanagement.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// EventController.java
@RestController
@RequestMapping("/events")
public class EventController {
    // Implement endpoints for CRUD operations
}