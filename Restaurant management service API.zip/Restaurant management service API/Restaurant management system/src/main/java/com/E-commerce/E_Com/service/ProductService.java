package com.university.eventmanagement.service;

import org.springframework.stereotype.Service;

// StudentService.java
@Service
public class StudentService {
    // Implement service methods for CRUD operations
}

