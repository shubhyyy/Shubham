package com.university.eventmanagement.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// StudentController.java
@RestController
@RequestMapping("/students")
public class StudentController {
    // Implement endpoints for CRUD operations
}


