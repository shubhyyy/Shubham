public @interface Min {
    String message();

    int value();
}
