public enum JobType {
    IT, HR, Sales, Marketing, // Add more job types as needed
}
