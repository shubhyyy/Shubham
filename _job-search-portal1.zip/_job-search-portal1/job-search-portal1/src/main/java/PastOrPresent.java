public @interface PastOrPresent {
    String message();
}
