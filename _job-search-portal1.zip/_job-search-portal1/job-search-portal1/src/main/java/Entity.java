public @interface Entity {
}
