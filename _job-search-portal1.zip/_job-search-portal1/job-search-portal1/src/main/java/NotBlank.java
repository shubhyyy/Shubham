public @interface NotBlank {
    String message();
}
